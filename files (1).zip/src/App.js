import React, { useEffect, useState, useRef } from 'react';
import io from 'socket.io-client';
import axios from 'axios';

const socket = io('http://localhost:5000');

function App() {
  const [messages, setMessages] = useState([]);
  const [user, setUser] = useState('');
  const [message, setMessage] = useState('');
  const bottomRef = useRef(null);

  useEffect(() => {
    // Fetch message history
    axios.get('http://localhost:5000/messages').then(res => setMessages(res.data));

    // Listen for new messages
    socket.on('message', msg => setMessages(prev => [...prev, msg]));

    // Cleanup
    return () => socket.off('message');
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!user || !message) return;
    socket.emit('send-message', { user, message });
    setMessage('');
  };

  return (
    <div style={{ maxWidth: 500, margin: '40px auto', border: '1px solid #eee', padding: 16, borderRadius: 8 }}>
      <h2>WhatsApp Clone</h2>
      <input
        placeholder="Your name"
        value={user}
        onChange={e => setUser(e.target.value)}
        style={{ width: '100%', marginBottom: 10 }}
      />
      <div style={{ height: 400, overflowY: 'auto', border: '1px solid #ccc', padding: 8, marginBottom: 10 }}>
        {messages.map((msg, idx) => (
          <div key={idx} style={{ textAlign: msg.user === user ? 'right' : 'left' }}>
            <strong>{msg.user}</strong>: {msg.message}
          </div>
        ))}
        <div ref={bottomRef}></div>
      </div>
      <form onSubmit={sendMessage} style={{ display: 'flex' }}>
        <input
          value={message}
          onChange={e => setMessage(e.target.value)}
          placeholder="Type a message"
          style={{ flex: 1, marginRight: 8 }}
        />
        <button type="submit">Send</button>
      </form>
    </div>
  );
}
export default App;